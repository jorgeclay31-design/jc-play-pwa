# JC PLAY — Android com catálogo

Inclui conexão Xtream Codes para TV ao vivo, filmes e séries; leitura de M3U/M3U8 com agrupamento por grupo e busca; player Media3; favoritos locais; credenciais protegidas com AES-GCM e Android Keystore.

## Compilar
Abra esta pasta no Android Studio, aguarde a sincronização Gradle e use Build > Build APK(s). Requer Android Studio recente e JDK 17.

## Limitações importantes
- Use apenas listas, servidores e conteúdos que você tenha autorização para acessar e distribuir.
- Endpoints e formatos Xtream variam por servidor.
- A listagem de séries está incluída, mas a reprodução de episódios exige consultar `get_series_info`; essa integração específica ainda precisa ser feita e validada com uma resposta real do seu servidor.
- EPG, downloads, controle parental, sincronização e publicação na Play Store não estão incluídos.
- O projeto precisa ser compilado e testado em aparelhos reais, além de assinado para distribuição. Este ZIP é código-fonte, não APK pronto.

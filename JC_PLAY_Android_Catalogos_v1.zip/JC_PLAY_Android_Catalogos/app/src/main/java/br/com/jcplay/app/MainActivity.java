package br.com.jcplay.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import android.text.InputType;
import android.util.Base64;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import okhttp3.*;
import org.json.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.util.*;
import java.io.*;
import java.net.*;

public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(8,19,31), PANEL=Color.rgb(17,34,49), CYAN=Color.rgb(22,199,217), WHITE=Color.WHITE, MUTED=Color.rgb(166,184,197);
    private EditText server, username, password, playlist;
    private RadioGroup mode;
    private TextView status;
    private ExoPlayer player;
    private PlayerView playerView;
    private OkHttpClient http=new OkHttpClient();
    private String connMode="xtream", baseUrl="", user="", pass="", m3uUrl="";
    private final ArrayList<MediaEntry> entries=new ArrayList<>();
    private final ArrayList<String> categories=new ArrayList<>();
    private String activeSection="TV AO VIVO";
    private LinearLayout listRoot;
    private EditText searchBox;

    static class MediaEntry {
        String name="", url="", category="", logo="", kind="";
        MediaEntry(String n,String u,String c,String l,String k){name=n;url=u;category=c;logo=l;kind=k;}
    }

    @Override public void onCreate(Bundle b){super.onCreate(b);loadConnectionIntoFields();showLogin();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(8),0,dp(8));return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(16),dp(20),dp(16));l.setBackgroundColor(BG);return l;}
    private EditText field(String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setInputType(type);e.setPadding(dp(14),dp(10),dp(14),dp(10));e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN));return e;}
    private void addField(LinearLayout root,EditText e){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.bottomMargin=dp(7);root.addView(e,p);}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(BG);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN));return b;}
    private void showLogin(){
        LinearLayout root=column();ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);
        TextView logo=label("JC PLAY",34,CYAN);logo.setGravity(Gravity.CENTER);root.addView(logo);
        TextView tagline=label("SUA TV, SEU JEITO",12,MUTED);tagline.setGravity(Gravity.CENTER);root.addView(tagline);
        root.addView(label("Conectar ao seu serviço",20,WHITE));
        mode=new RadioGroup(this);mode.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton xt=new RadioButton(this);xt.setText("Xtream Codes");xt.setTextColor(WHITE);xt.setId(1);
        RadioButton m3u=new RadioButton(this);m3u.setText("M3U / M3U8");m3u.setTextColor(WHITE);m3u.setId(2);
        mode.addView(xt);mode.addView(m3u);root.addView(mode);
        server=field("URL do servidor (https://...)",InputType.TYPE_TEXT_VARIATION_URI);addField(root,server);
        username=field("Usuário",InputType.TYPE_CLASS_TEXT);addField(root,username);
        password=field("Senha",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);addField(root,password);
        playlist=field("URL completa da lista M3U / M3U8",InputType.TYPE_TEXT_VARIATION_URI);addField(root,playlist);
        mode.setOnCheckedChangeListener((g,id)->updateModeFields(id==1));
        Button enter=button("ENTRAR");root.addView(enter,new LinearLayout.LayoutParams(-1,dp(52)));
        status=label("Acesso salvo com criptografia no aparelho.",12,MUTED);root.addView(status);
        Button restore=button("CARREGAR ACESSO SALVO");root.addView(restore);
        mode.check(connMode.equals("xtream")?1:2);updateModeFields(connMode.equals("xtream"));
        enter.setOnClickListener(v->{
            boolean x=mode.getCheckedRadioButtonId()==1;
            String s=server.getText().toString().trim(),u=username.getText().toString().trim(),p=password.getText().toString(),m=playlist.getText().toString().trim();
            if(x&&(s.isEmpty()||u.isEmpty()||p.isEmpty())){status.setText("Preencha URL, usuário e senha.");return;}
            if(!x&&m.isEmpty()){status.setText("Informe a URL da lista M3U/M3U8.");return;}
            connMode=x?"xtream":"m3u";baseUrl=trimSlash(s);user=u;pass=p;m3uUrl=m;
            try{save();}catch(Exception e){status.setText("Falha ao proteger os dados de acesso.");return;}
            hideKeyboard();loadCatalog();
        });
        restore.setOnClickListener(v->{if(loadSaved()){status.setText("Acesso recuperado.");server.setText(baseUrl);username.setText(user);password.setText(pass);playlist.setText(m3uUrl);mode.check(connMode.equals("xtream")?1:2);}else status.setText("Nenhum acesso salvo encontrado.");});
    }
    private void updateModeFields(boolean x){server.setVisibility(x?View.VISIBLE:View.GONE);username.setVisibility(x?View.VISIBLE:View.GONE);password.setVisibility(x?View.VISIBLE:View.GONE);playlist.setVisibility(x?View.GONE:View.VISIBLE);}
    private String trimSlash(String s){while(s.endsWith("/"))s=s.substring(0,s.length()-1);return s;}
    private String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private void loadCatalog(){
        showLoading("Carregando catálogo...");
        if(connMode.equals("m3u")){loadM3u();return;}
        fetchXtreamSection("TV AO VIVO");
    }
    private void showLoading(String msg){LinearLayout r=column();setContentView(r);r.addView(label("JC PLAY",30,CYAN));r.addView(label(msg,16,WHITE));}
    private void fetchXtreamSection(String section){
        activeSection=section;showLoading("Buscando "+section.toLowerCase(Locale.ROOT)+"...");
        String action;
        if(section.equals("TV AO VIVO"))action="get_live_streams";
        else if(section.equals("FILMES"))action="get_vod_streams";
        else action="get_series";
        String url=baseUrl+"/player_api.php?username="+enc(user)+"&password="+enc(pass)+"&action="+action;
        Request req=new Request.Builder().url(url).get().build();
        http.newCall(req).enqueue(new Callback(){
            public void onFailure(Call c,IOException e){runOnUiThread(()->showError("Não foi possível carregar o catálogo. Confira a conexão e tente novamente."));}
            public void onResponse(Call c,Response r)throws IOException{
                String body=r.body()!=null?r.body().string():"";
                ArrayList<MediaEntry> result=new ArrayList<>();
                try{JSONArray a=new JSONArray(body);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;
                    String name=o.optString("name","Sem título"),id=o.optString("stream_id",o.optString("series_id",""));
                    String ext=o.optString("container_extension",section.equals("FILMES")?"mp4":"");
                    String stream;
                    if(section.equals("TV AO VIVO"))stream=baseUrl+"/live/"+enc(user)+"/"+enc(pass)+"/"+id+".ts";
                    else if(section.equals("FILMES"))stream=baseUrl+"/movie/"+enc(user)+"/"+enc(pass)+"/"+id+"."+ext;
                    else stream=baseUrl+"/series/"+enc(user)+"/"+enc(pass)+"/"+id;
                    String cat=o.optString("category_name","Outros"),logo=o.optString("stream_icon",o.optString("cover",""));
                    result.add(new MediaEntry(name,stream,cat,logo,section));
                }}catch(Exception ignored){}
                runOnUiThread(()->{entries.clear();entries.addAll(result);showCatalog(section);});
            }
        });
    }
    private void loadM3u(){
        showLoading("Lendo lista M3U/M3U8...");
        Request req=new Request.Builder().url(m3uUrl).get().build();
        http.newCall(req).enqueue(new Callback(){
            public void onFailure(Call c,IOException e){runOnUiThread(()->showError("Não foi possível baixar a lista. Confira o endereço M3U."));}
            public void onResponse(Call c,Response r)throws IOException{
                String body=r.body()!=null?r.body().string():"";ArrayList<MediaEntry> parsed=parseM3u(body);
                runOnUiThread(()->{entries.clear();entries.addAll(parsed);activeSection="TV AO VIVO";showCatalog("LISTA M3U");});
            }
        });
    }
    private ArrayList<MediaEntry> parseM3u(String data){
        ArrayList<MediaEntry> out=new ArrayList<>();String name="Canal",cat="Outros",logo="",kind="TV AO VIVO";
        try(BufferedReader br=new BufferedReader(new StringReader(data))){
            String line;while((line=br.readLine())!=null){line=line.trim();if(line.startsWith("#EXTINF")){
                name="Canal";cat="Outros";logo="";
                int comma=line.lastIndexOf(',');if(comma>=0&&comma<line.length()-1)name=line.substring(comma+1).trim();
                name=attr(line,"tvg-name",name);cat=attr(line,"group-title","Outros");logo=attr(line,"tvg-logo","");
            }else if(!line.isEmpty()&&!line.startsWith("#")){
                out.add(new MediaEntry(name,line,cat,logo,kind));name="Canal";
            }}
        }catch(Exception ignored){}return out;
    }
    private String attr(String line,String key,String fallback){
        String needle=key+"=\"";int i=line.indexOf(needle);if(i<0)return fallback;i+=needle.length();int end=line.indexOf('"',i);return end<0?fallback:line.substring(i,end);
    }
    private void showCatalog(String section){
        LinearLayout root=column();setContentView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header);
        TextView title=label("JC PLAY",28,CYAN);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button back=button("CONEXÃO");header.addView(back);back.setOnClickListener(v->showLogin());
        root.addView(label(section+"  •  "+entries.size()+" itens",16,WHITE));
        if(connMode.equals("xtream")){
            LinearLayout tabs=new LinearLayout(this);root.addView(tabs);
            for(String s:new String[]{"TV AO VIVO","FILMES","SÉRIES"}){Button b=button(s);tabs.addView(b,new LinearLayout.LayoutParams(0,dp(46),1));b.setOnClickListener(v->fetchXtreamSection(s));}
        }
        searchBox=field("Buscar no catálogo...",InputType.TYPE_CLASS_TEXT);root.addView(searchBox,new LinearLayout.LayoutParams(-1,dp(48)));
        ScrollView scroll=new ScrollView(this);listRoot=new LinearLayout(this);listRoot.setOrientation(LinearLayout.VERTICAL);scroll.addView(listRoot);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        searchBox.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){renderEntries(s.toString());}public void afterTextChanged(android.text.Editable e){}});
        renderEntries("");
        Button fav=button("FAVORITOS");root.addView(fav);fav.setOnClickListener(v->showFavorites());
    }
    private void renderEntries(String query){
        if(listRoot==null)return;listRoot.removeAllViews();String q=query.toLowerCase(Locale.ROOT);
        LinkedHashSet<String> cats=new LinkedHashSet<>();for(MediaEntry e:entries)if(e.name.toLowerCase(Locale.ROOT).contains(q)||e.category.toLowerCase(Locale.ROOT).contains(q))cats.add(e.category);
        if(!q.isEmpty())listRoot.addView(label("Resultados da busca",14,CYAN));
        for(String cat:cats){
            TextView h=label(cat,16,CYAN);listRoot.addView(h);
            for(MediaEntry e:entries){if(!e.category.equals(cat)||(!q.isEmpty()&&!e.name.toLowerCase(Locale.ROOT).contains(q)&&!e.category.toLowerCase(Locale.ROOT).contains(q)))continue;
                LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(3),0,dp(3));row.setBackgroundColor(PANEL);
                TextView n=label(e.name,14,WHITE);row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
                Button play=button("▶");row.addView(play);play.setOnClickListener(v->play(e.url,e.name));
                Button star=button("☆");row.addView(star);star.setOnClickListener(v->{toggleFavorite(e);star.setText(isFavorite(e)?"★":"☆");});
                listRoot.addView(row,new LinearLayout.LayoutParams(-1,-2));
                View gap=new View(this);listRoot.addView(gap,new LinearLayout.LayoutParams(1,dp(5)));
            }
        }
        if(cats.isEmpty())listRoot.addView(label("Nenhum item encontrado.",14,MUTED));
    }
    private void showFavorites(){
        ArrayList<MediaEntry> all=new ArrayList<>(entries);entries.clear();
        Set<String> fav=getSharedPreferences("jc_favs",MODE_PRIVATE).getStringSet("items",new HashSet<>());
        for(MediaEntry e:all)if(fav.contains(e.url))entries.add(e);
        showCatalog("FAVORITOS");entries.clear();entries.addAll(all);
    }
    private boolean isFavorite(MediaEntry e){return getSharedPreferences("jc_favs",MODE_PRIVATE).getStringSet("items",new HashSet<>()).contains(e.url);}
    private void toggleFavorite(MediaEntry e){Set<String>s=new HashSet<>(getSharedPreferences("jc_favs",MODE_PRIVATE).getStringSet("items",new HashSet<>()));if(s.contains(e.url))s.remove(e.url);else s.add(e.url);getSharedPreferences("jc_favs",MODE_PRIVATE).edit().putStringSet("items",s).apply();}
    private void play(String url,String title){
        if(url==null||url.trim().isEmpty())return;
        LinearLayout root=column();TextView h=label(title,18,WHITE);root.addView(h);
        playerView=new PlayerView(this);root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1));Button back=button("VOLTAR AO CATÁLOGO");root.addView(back);back.setOnClickListener(v->{if(connMode.equals("m3u"))showCatalog("LISTA M3U");else showCatalog(activeSection);});
        setContentView(root);releasePlayer();player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();
        getSharedPreferences("jc_history",MODE_PRIVATE).edit().putString("last_title",title).putString("last_url",url).apply();
    }
    private void showError(String s){new AlertDialog.Builder(this).setTitle("JC PLAY").setMessage(s).setPositiveButton("Tentar novamente",(d,w)->loadCatalog()).setNegativeButton("Voltar",(d,w)->showLogin()).show();}
    private void save()throws Exception{JSONObject j=new JSONObject();j.put("mode",connMode);j.put("server",baseUrl);j.put("username",user);j.put("password",pass);j.put("playlist",m3uUrl);getSharedPreferences("jc_secure",MODE_PRIVATE).edit().putString("access",encrypt(j.toString())).apply();}
    private boolean loadSaved(){try{String v=getSharedPreferences("jc_secure",MODE_PRIVATE).getString("access",null);if(v==null)return false;JSONObject j=new JSONObject(decrypt(v));connMode=j.optString("mode","xtream");baseUrl=j.optString("server","");user=j.optString("username","");pass=j.optString("password","");m3uUrl=j.optString("playlist","");return true;}catch(Exception e){return false;}}
    private void loadConnectionIntoFields(){loadSaved();}
    private SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("jc_play_key")){KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(new android.security.keystore.KeyGenParameterSpec.Builder("jc_play_key",android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());kg.generateKey();}return ((KeyStore.SecretKeyEntry)ks.getEntry("jc_play_key",null)).getSecretKey();}
    private String encrypt(String p)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[]iv=c.getIV(),d=c.doFinal(p.getBytes(StandardCharsets.UTF_8)),a=new byte[iv.length+d.length];System.arraycopy(iv,0,a,0,iv.length);System.arraycopy(d,0,a,iv.length,d.length);return Base64.encodeToString(a,Base64.NO_WRAP);}
    private String decrypt(String s)throws Exception{byte[]a=Base64.decode(s,Base64.NO_WRAP),iv=Arrays.copyOfRange(a,0,12),d=Arrays.copyOfRange(a,12,a.length);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));return new String(c.doFinal(d),StandardCharsets.UTF_8);}
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(server.getWindowToken(),0);}catch(Exception ignored){}}
    private void releasePlayer(){if(player!=null){player.release();player=null;}}
    @Override protected void onStop(){super.onStop();releasePlayer();}
}

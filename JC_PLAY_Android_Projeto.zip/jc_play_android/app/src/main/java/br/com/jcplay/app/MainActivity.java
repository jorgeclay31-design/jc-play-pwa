package br.com.jcplay.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import android.text.InputType;
import android.util.Base64;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import okhttp3.*;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(8,19,31), PANEL = Color.rgb(17,34,49), CYAN = Color.rgb(22,199,217), WHITE = Color.WHITE, MUTED = Color.rgb(166,184,197);
    private EditText server, username, password, playlist;
    private RadioGroup mode;
    private TextView status;
    private ExoPlayer player;
    private PlayerView playerView;

    @Override public void onCreate(Bundle b) { super.onCreate(b); showLogin(); }

    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(null, Typeface.BOLD); t.setPadding(0, dp(8), 0, dp(8)); return t;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(24),dp(20),dp(24),dp(20)); l.setBackgroundColor(BG); return l; }
    private EditText field(String hint, int type) { EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setInputType(type); e.setPadding(dp(14),dp(12),dp(14),dp(12)); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin=dp(8); return e; }
    private void addField(LinearLayout root, EditText e) { root.addView(e, new LinearLayout.LayoutParams(-1, dp(54))); }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setTextColor(BG); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CYAN)); return b; }

    private void showLogin() {
        LinearLayout root=column(); ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView logo=label("JC PLAY",34,CYAN); logo.setGravity(Gravity.CENTER); logo.setPadding(0,dp(28),0,dp(4)); root.addView(logo);
        TextView tagline=label("SUA TV, SEU JEITO",12,MUTED); tagline.setGravity(Gravity.CENTER); root.addView(tagline);
        root.addView(label("Conectar ao seu serviço",20,WHITE));
        mode=new RadioGroup(this); mode.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton xt=new RadioButton(this); xt.setText("Xtream Codes"); xt.setTextColor(WHITE); xt.setId(1); xt.setChecked(true);
        RadioButton m3u=new RadioButton(this); m3u.setText("M3U / M3U8"); m3u.setTextColor(WHITE); m3u.setId(2);
        mode.addView(xt); mode.addView(m3u); root.addView(mode);
        server=field("URL do servidor (https://...)",InputType.TYPE_TEXT_VARIATION_URI); addField(root,server);
        username=field("Usuário",InputType.TYPE_CLASS_TEXT); addField(root,username);
        password=field("Senha",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); addField(root,password);
        playlist=field("URL completa da lista M3U / M3U8",InputType.TYPE_TEXT_VARIATION_URI); playlist.setVisibility(View.GONE); addField(root,playlist);
        mode.setOnCheckedChangeListener((g,id)->{ boolean x=id==1; username.setVisibility(x?View.VISIBLE:View.GONE); password.setVisibility(x?View.VISIBLE:View.GONE); playlist.setVisibility(x?View.GONE:View.VISIBLE); server.setHint(x?"URL do servidor (https://...)":"Nome da conexão (opcional)"); });
        Button enter=button("ENTRAR"); root.addView(enter,new LinearLayout.LayoutParams(-1,dp(54)));
        status=label("Seus dados ficam salvos com proteção no aparelho.",12,MUTED); root.addView(status);
        enter.setOnClickListener(v->{
            String s=server.getText().toString().trim(), u=username.getText().toString().trim(), p=password.getText().toString(); boolean x=mode.getCheckedRadioButtonId()==1;
            if(x && (s.isEmpty()||u.isEmpty()||p.isEmpty())) { status.setText("Preencha URL, usuário e senha."); return; }
            if(!x && playlist.getText().toString().trim().isEmpty()) { status.setText("Informe a URL da lista M3U/M3U8."); return; }
            try { save(x,s,u,p,playlist.getText().toString().trim()); } catch(Exception ex) { status.setText("Não foi possível salvar os dados neste aparelho."); return; }
            hideKeyboard();
            if(x) validateXtream(s,u,p); else showHome("Lista M3U/M3U8 adicionada. Selecione um endereço de reprodução para testar.");
        });
        Button restore=button("CARREGAR ACESSO SALVO"); root.addView(restore); restore.setOnClickListener(v->loadSaved());
    }

    private void validateXtream(String s,String u,String p) {
        status.setText("Verificando conexão...");
        String base=s.endsWith("/")?s.substring(0,s.length()-1):s;
        String url=base+"/player_api.php?username="+enc(u)+"&password="+enc(p);
        OkHttpClient client=new OkHttpClient(); Request req=new Request.Builder().url(url).get().build();
        client.newCall(req).enqueue(new Callback(){
            public void onFailure(Call c, java.io.IOException e){runOnUiThread(()->status.setText("Não foi possível conectar. Confira a URL e a internet."));}
            public void onResponse(Call c,Response r)throws java.io.IOException { String body=r.body()!=null?r.body().string():""; boolean ok=false; try { JSONObject j=new JSONObject(body); ok=j.has("user_info"); } catch(Exception ignored){} final boolean valid=ok; runOnUiThread(()->{ if(valid) showHome("Conexão confirmada. Escolha uma categoria quando a integração de catálogo estiver configurada."); else status.setText("Servidor respondeu, mas não reconheci os dados Xtream. Confira as informações."); }); }
        });
    }
    private String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private void showHome(String message) {
        LinearLayout root=column(); setContentView(root);
        root.addView(label("JC PLAY",30,CYAN)); root.addView(label("Sua biblioteca",22,WHITE));
        TextView msg=label(message,14,MUTED); root.addView(msg);
        String[] items={"TV AO VIVO","FILMES","SÉRIES","FAVORITOS","HISTÓRICO"};
        for(String item:items){ Button b=button(item); root.addView(b,new LinearLayout.LayoutParams(-1,dp(52))); b.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(item).setMessage("A integração do catálogo desta seção será concluída na próxima etapa, usando seu serviço autorizado.").setPositiveButton("OK",null).show()); }
        Button change=button("TROCAR CONEXÃO"); root.addView(change); change.setOnClickListener(v->showLogin());
        Button playTest=button("TESTAR UM LINK DE VÍDEO"); root.addView(playTest); playTest.setOnClickListener(v->askStream());
    }
    private void askStream(){ EditText input=new EditText(this); input.setHint("URL autorizada do vídeo/stream"); new AlertDialog.Builder(this).setTitle("Teste do player").setView(input).setPositiveButton("REPRODUZIR",(d,w)->play(input.getText().toString().trim())).setNegativeButton("Cancelar",null).show(); }
    private void play(String url){ if(url.isEmpty())return; LinearLayout root=column(); playerView=new PlayerView(this); root.addView(playerView,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); player=new ExoPlayer.Builder(this).build(); playerView.setPlayer(player); player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play(); }
    private void save(boolean x,String s,String u,String p,String m)throws Exception{ JSONObject j=new JSONObject(); j.put("mode",x?"xtream":"m3u"); j.put("server",s); j.put("username",u); j.put("password",p); j.put("playlist",m); String encrypted=encrypt(j.toString()); getSharedPreferences("jc_secure",MODE_PRIVATE).edit().putString("access",encrypted).apply(); }
    private void loadSaved(){ try { String v=getSharedPreferences("jc_secure",MODE_PRIVATE).getString("access",null); if(v==null){status.setText("Ainda não há acesso salvo.");return;} JSONObject j=new JSONObject(decrypt(v)); boolean x=j.getString("mode").equals("xtream"); server.setText(j.optString("server")); username.setText(j.optString("username")); password.setText(j.optString("password")); playlist.setText(j.optString("playlist")); mode.check(x?1:2); status.setText("Acesso carregado com segurança."); }catch(Exception e){status.setText("Não foi possível recuperar o acesso salvo.");} }
    private SecretKey key() throws Exception { KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null); if(!ks.containsAlias("jc_play_key")){ KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore"); kg.init(new android.security.keystore.KeyGenParameterSpec.Builder("jc_play_key",android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build()); kg.generateKey(); } return ((KeyStore.SecretKeyEntry)ks.getEntry("jc_play_key",null)).getSecretKey(); }
    private String encrypt(String plain)throws Exception{ Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key()); byte[] iv=c.getIV(), data=c.doFinal(plain.getBytes(StandardCharsets.UTF_8)); byte[] all=new byte[iv.length+data.length]; System.arraycopy(iv,0,all,0,iv.length); System.arraycopy(data,0,all,iv.length,data.length); return Base64.encodeToString(all,Base64.NO_WRAP); }
    private String decrypt(String encoded)throws Exception{ byte[] all=Base64.decode(encoded,Base64.NO_WRAP); byte[] iv=new byte[12], data=new byte[all.length-12]; System.arraycopy(all,0,iv,0,12); System.arraycopy(all,12,data,0,data.length); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv)); return new String(c.doFinal(data),StandardCharsets.UTF_8); }
    private void hideKeyboard(){ try{ ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(server.getWindowToken(),0);}catch(Exception ignored){} }
    @Override protected void onStop(){ super.onStop(); if(player!=null){player.release();player=null;} }
}

# JC PLAY — projeto inicial Android

Projeto-fonte inicial de um player Android com identidade JC PLAY.

## Incluído nesta base
- Interface inicial escura com acento azul-turquesa.
- Seleção de conexão Xtream Codes ou M3U/M3U8.
- Armazenamento local cifrado de URL/usuário/senha/lista usando AES-GCM e Android Keystore.
- Verificação básica do endpoint `player_api.php` para Xtream.
- Player de teste com AndroidX Media3/ExoPlayer para URL de mídia fornecida pelo usuário.

## Ainda precisa ser concluído antes de distribuir
- Catálogo completo de TV ao vivo, filmes e séries (categorias, paginação, imagens e detalhes).
- Parser M3U/M3U8 com seleção de canais/itens e tratamento de cabeçalhos/tokens.
- Recuperação automática da conexão salva ao abrir o app.
- Tratamento de URLs HTTP/HTTPS e políticas de segurança específicas do servidor.
- Testes em aparelhos reais, ícone adaptativo, splash screen, política de privacidade e assinatura do APK.
- Revisão de segurança e conformidade com direitos de distribuição dos streams.

## Como compilar
Abra a pasta `jc_play_android` no Android Studio (versão compatível com Android Gradle Plugin 8.7.3), sincronize o Gradle e gere o APK de debug para testes. O ambiente desta conversa não possui Android SDK/Gradle configurado, então este pacote é o código-fonte inicial, não um APK compilado.

Não coloque credenciais reais em arquivos de código ou mensagens. Teste somente com um servidor e conteúdos que você esteja autorizado a utilizar.
